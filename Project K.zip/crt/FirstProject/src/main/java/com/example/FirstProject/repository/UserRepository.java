package com.example.FirstProject.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.FirstProject.model.Users;

@Repository
public interface UserRepository extends JpaRepository<Users,Integer>
{
    Users findByUsername(String name);

}
//wrapper classes 
//int >INTEGER -> 4 bytes  
//byte ->Byte ->2 bytes
//short -> Short-> 2 bytes
//Long *> long -> 8 bytes
//1byte=8 bits