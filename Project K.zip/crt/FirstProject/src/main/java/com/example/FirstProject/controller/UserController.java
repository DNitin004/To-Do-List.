package com.example.FirstProject.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import com.example.FirstProject.model.Book;
import com.example.FirstProject.model.Users;
import com.example.FirstProject.repository.BookRepository;
import com.example.FirstProject.repository.UserRepository;

@Controller
//@RestController
//@CrossOrigin(origins="http://localhost:5173")

public class UserController 
{
    @Autowired
    UserRepository ur;
    
    @Autowired
    BookRepository br;

    @GetMapping("/reg")
    String m1()
    {
        return "register";
    }

    @PostMapping("/register")
    String m2(@RequestBody Users u)
    {
       Users result= this.ur.findByUsername(u.getUsername());
        if(result!=null)
        {
            return "username exists";
        }
        this.ur.save(u);
        return "registerSuccess";
    }
       
    
   // String m2(String username, String email, String password, Model model)
  //  {
        

     //   Users u=new Users();
      //  u.setUsername(username);
       // u.setEmail(email);
       // u.setPassword(password);
       // this.ur.save(u);
       // return "registerSuccess";
  //  }

    @GetMapping("/log")
    String m3()
    {
        return "login";
    }

    @PostMapping("/login")
    String m4(@RequestBody Users u)
    {
       Users result= this.ur.findByUsername(u.getUsername());
        if(result!=null)
        {
            return "username exists";
        }
        this.ur.save(u);
        return "LoginSuccess";
    }

    

    

   // String m4(String username,String password,Model model)
    //{
     //   Users result=this.ur.findByUsername(username);
      //  if(result != null && result.getPassword().equals(password))
       // {
       //     return "loginSuccess";
       // }
       // return "login";

    //}
    @GetMapping("/upd")
    String m5()
    {
        return "update";
    }

    @PostMapping("/update")
    String update(String username,String opassword,String npassword)
    {
        Users result= this.ur.findByUsername(username);
        if(result != null && result.getPassword().equals(opassword))
        {
            result.setPassword(npassword);
            this.ur.save(result);
            return "login";
        }
        return "update";

    }

    @GetMapping("/del")
    String m6()
    {
        return "delete";
    }

    @PostMapping("/delete")
    String delete(String username,String password)
    {
        Users result= this.ur.findByUsername(username);
        if(result != null && result.getPassword().equals(password))
        {
            this.ur.delete(result);
            return "login";
        }
        return "delete";

    }

    @GetMapping("/book")
   String showBookForm() {
    return "book";  
}
    @PostMapping("/addbook")
    String addBook(@RequestBody Book book) {
    Book existingBook = this.br.findByTitle(book.getTitle());
    if (existingBook != null) {
        return "book exists";
    } else {
        this.br.save(book);
        return "addbook";
    }
}

    

}
