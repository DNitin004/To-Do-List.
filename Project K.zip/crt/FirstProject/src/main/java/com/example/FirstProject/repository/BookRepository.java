package com.example.FirstProject.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.FirstProject.model.Book;

public interface BookRepository extends JpaRepository<Book, Long> {
    Book findByTitle(String title);
}
