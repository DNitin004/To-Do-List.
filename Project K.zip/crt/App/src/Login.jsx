import axios from "axios";
import { useState } from "react";
import { useNavigate } from "react-router-dom";

function Login() {
    const navigate = useNavigate(); // Corrected: useNavigate should be called as a function
    const [form, setForm] = useState({
        username: "",
        password: ""
    });

    const submitForm = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post("http://localhost:1232/login", form);
            alert(response.data);
            navigate("/admin");
        } catch (error) {
            alert("Login failed: " + error.response?.data || error.message);
        }
    };

    const changeForm = (e) => {
        setForm({ ...form, [e.target.name]: e.target.value });
    };

    return (
        <>
            <h1>Welcome to Login</h1>
            <form onSubmit={submitForm}>
                <input onChange={changeForm} type="text" name="username" placeholder="Enter username" /><br />
                <input onChange={changeForm} type="password" name="password" placeholder="Enter password" /><br />
                <button type="submit">Login</button>
            </form>
        </>
    );
}

export default Login;
