import axios from "axios";
import { useState } from "react";

function AddBook() {
    const [form, setForm] = useState({
        title: "",
        author: "",
        description: ""
    });

    const submitForm = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post("http://localhost:1232/book/addbook", form);
            console.log(response);
            alert(response.data);
        } catch (error) {
            if (error.response && error.response.status === 409) {
                alert(error.response.data);
            } else {
                alert("Something went wrong");
            }
        }
    };

    const changeData = (e) => {
        setForm({ ...form, [e.target.name]: e.target.value });
    };

    return (
        <>
            <h1>Add a Book</h1>
            <form onSubmit={submitForm}>
                <input onChange={changeData} type="text" name="title" placeholder="Enter title" /><br />
                <input onChange={changeData} type="text" name="author" placeholder="Enter author name" /><br />
                <input onChange={changeData} type="text" name="description" placeholder="Write about the book..." /><br />
                <button type="submit">Add Book</button>
            </form>
        </>
    );
}

export default AddBook;
