import { Link } from "react-router-dom"

function Admin()
{
    return(
        <>
        <h1>you are Admin</h1>
        <Link to="/library">click here to visit library</Link>
        </>
    )
}
export default Admin