import { BrowserRouter, Route, Routes } from "react-router-dom"
import Register from "./Register"
import Login from "./Login"
import Home from "./Home"
import Library from "./Library"
import Admin from "./Admin"
import AddBook from "./books/AddBook"
import AuthorBook from "./books/AuthorBook"
import ViewAll from "./books/ViewAll"
function App()
{
  return(
    <>
      <BrowserRouter>
          <Routes>
            <Route path="/" element={<Home/>}/>
            <Route path="/reg" element={<Register/>}/>
            <Route path="/log" element={<Login/>}/>
            <Route path="/admin" element={<Admin/>}/>
            <Route path="/library" element={<Library/>}/>
            <Route path="/abook" element={<AddBook/>}/>
            <Route path="/vauthorbooks" element={<AuthorBook/>}/>
            <Route path="/viewall" element={<ViewAll/>}/>
          </Routes>
      </BrowserRouter>
    </>
  )
}
export default App